n = int(input("Quantos termos da sequencia de Fibonacci? "))
primeiro = 1
segundo = 1
terceiro = primeiro + segundo

if (n == 1):
    print(primeiro)
elif (n == 2):
    print(primeiro)
    print(segundo)
else:
    print(primeiro) 
    print(segundo)
    print(terceiro) 
    
    for i in range(n-3):  
        primeiro = segundo
        segundo = terceiro 
        terceiro = primeiro + segundo 
        print(terceiro) 