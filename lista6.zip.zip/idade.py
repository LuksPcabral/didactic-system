pessoas = int(input("Quantas pessoas na sala? "))

for i in range (1, pessoas+1):
    n = int(input("Qual eh a sua idade? "))
    n += n   

media = n / pessoas
if 0 <= media <= 25 :
    print("Essa turma eh jovem.")
elif 26 <= media <= 60 :
    print("Essa turma eh adulta.")
else:
    print("Essa turma eh idosa.") 