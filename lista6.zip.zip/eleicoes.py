eleitores = int(input("Qual eh o numero total de eleitores? "))
a = 0
b = 0
c = 0   

for i in range (eleitores):
    i = int(input("Digite o numero do seu candidato (11, 55 ou 88): "))
    
    if(i == 11):
        a += 1
    if(i == 55):
        b += 1
    if(i == 88):
        c += 1
    
print ("O candidato 11 recebeu %d votos." %a)
print ("O candidato 55 recebeu %d votos." %b)
print ("O candidato 88 recebeu %d votos." %c)