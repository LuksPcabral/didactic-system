n = int(input("Digite um numero: "))
if (n ==  0) or (n == 1):
   print ("O numero digitando nao eh um numero primo!")
if n ==  2 :
   print ("O numero digitando eh um numero primo!")

for p in range (2, n):
    if (n % p == 0): 
        print ("O numero digitado nao eh um numero primo!") 
    if (n % p != 0): 
        print ("O numero digitado eh um numero primo!")
    break