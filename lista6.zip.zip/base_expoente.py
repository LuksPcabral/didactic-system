base = int(input("Digite um numero para ser a base: "))
expoente = int(input("Digite outro numero para ser o expoente: "))
potencia = 1

for t in range (expoente):
    potencia *= base
    t += 1
print (base, '^' ,expoente,' =' ,potencia)