deposito = float(input("Digite o valor do deposito: "))
juros = float(input("Digite o valor dos juros: "))
mes = 1
saldo = deposito
while mes <=24:
    saldo = saldo + (saldo * (juros / 100))
    print(f"Saldo do mês {mes} é de R${saldo:5.2f}.")
    mes = mes + 1
print(f"O ganho obtido com os juros foi de R${saldo-deposito:8.2f}.")