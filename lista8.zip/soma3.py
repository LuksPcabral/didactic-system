def positive_or_negative(num):
    if num > 0:
        return 'P'
    else:
        return 'N'
print(positive_or_negative(5))
