# -*- coding: utf-8 -*-
"""
Escreva uma função que receba três argumentos (parâmetros) e 
retorne sua soma. Escreva um programa para testá-la. 

"""
def soma3(a, b, c):
    s = a + b + c
    return s


print('SOMA DE TRÊS NÚMEROS')
a = int(input('Primeiro número: '))
b = int(input('Segundo número: '))
c = int(input('Terceiro número: '))

print('Soma = ', soma3(a, b, c))
