# -*- coding: utf-8 -*-
"""
Faça uma função que retorne a quantidade de dígitos de um determinado 
número inteiro passado por parâmetro. 

"""

def inteiros(n):
    return len((str(n)))

n = str(input('Digite um número: ')).strip()
print(f'Esse número tem {inteiros(n)} dígitos')
