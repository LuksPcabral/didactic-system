# -*- coding: utf-8 -*-
"""
Escreva um programa que elimina os brancos de uma 
string digitada pelo usuário. 

"""

string = input("Digite uma string: ")
nova_string = ""

for char in string:
    if char != " ":
        nova_string += char

print(nova_string)