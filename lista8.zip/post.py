def Pos_Ngt(num):
    if num > 0:
        print("Numero positivo!")
    else:
        print("Numero negativo!")
