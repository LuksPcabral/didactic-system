def number_to_words(number):
    ones = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
    tens = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
    if number < 10:
        return ones[number]
    elif number < 20:
        if number == 11:
            return "onze"
        elif number == 12:
            return "doze"
        elif number == 13:
            return "treze"
        elif number == 14:
            return "quatorze"
        elif number == 15:
            return "quinze"
        elif number == 16:
            return "dezesseis"
        elif number == 17:
            return "dezessete"
        elif number == 18:
            return "dezoito"
        elif number == 19:
            return "dezenove"
    else:
        ten_digit = int(number / 10)
        one_digit = int(number % 10)
        if one_digit == 0:
            return tens[ten_digit]
        else:
            return tens[ten_digit] + "-" + ones[one_digit]

number = int(input("Digite um número de 1 a 99: "))
print(number_to_words(number))
