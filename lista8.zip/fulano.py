# -*- coding: utf-8 -*-
"""
Escreva um programa em Python que receba uma string e a imprima 
na vertical e em formato de escada. Por exemplo, se o usuário 
digitar a string FULANO, o programa deve exibir a seguinte saída: 
"""

def vertical_print(string):
    for i in range(len(string)):
        print(string[:i+1])

string = input("Digite uma string: ")
vertical_print(string)
