import random

def hangman():
    palavras = ["abacaxi", "banana", "caju", "damasco", "figo", "goiaba", "laranja", "manga", "nectarina", "pera"]
    palavra = random.choice(palavras)
    letras_certas = set()
    letras_erradas = set()
    tentativas = 6

    while True:
        print("Palavra: ", end="")
        for letra in palavra:
            if letra in letras_certas:
                print(letra, end="")
            else:
                print("_", end="")
        print()

        if len(letras_certas) == len(set(palavra)):
            print("Parabéns! Você acertou a palavra!")
            break

        if tentativas == 0:
            print("Você foi enforcado! A palavra era:", palavra)
            break

        print("Tentativas restantes:", tentativas)
        letra = input("Digite uma letra: ").lower()

        if letra in letras_certas or letra in letras_erradas:
            print("Você já tentou essa letra. Tente outra.")
        elif letra in palavra:
            letras_certas.add(letra)
        else:
            letras_erradas.add(letra)
            tentativas -= 1
            print("Letra incorreta. Tente novamente.")

hangman()
