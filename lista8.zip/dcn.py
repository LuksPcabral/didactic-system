# -*- coding: utf-8 -*-
"""
Faça um programa que exiba na tela o número de 
ocorrências de cada caractere de uma frase digitada 
pelo usuário. A contagem dos caracteres deve ocorrer
dentro de uma função que recebe uma string por 
parâmetro e retorna um dicionário cuja chave é o 
próprio caractere e o valor corresponde ao número 
de vezes que ele aparece na string. 
"""

def contar_caracteres(frase):
    dicionario = {}
    for letra in frase:
        if letra in dicionario:
            dicionario[letra] += 1
        else:
            dicionario[letra] = 1
    return dicionario

frase = input("Digite uma frase: ")
resultado = contar_caracteres(frase)
print(resultado)
