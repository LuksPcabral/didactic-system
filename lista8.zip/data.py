"""
Faça um programa que solicite a data de nascimento 
(dd/mm/aaaa) e imprima com o nome do mês por extenso. 

"""

dia = input("Digite o dia do seu nascimento: ")
mes = input("Digite o mes do seu nascimento: ")
ano = input("Digite o ano do seu nascimento: ")
print(dia+"/"+mes+"/"+ano)
