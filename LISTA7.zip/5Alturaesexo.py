altura = []
sexo = []
soma = 0
menor = 0
maior = 0
quantidade = 0
sexo_maior = 0
sexo_menor = 0
media_feminina = 0
media_masculina = 0

for i in range(2):
    altura.append(input("Digite a sua altura: "))
    sexo.append(input("Digite o seu sexo(M ou F): ")) 
    menor = maior = altura[i] 
    
    if altura[i] > maior:
        maior = altura[i] 
        sexo_maior = sexo[i] 
        quantidade += 1
        
    else:
        menor = altura[i] 
        sexo_menor = sexo[i]
        quantidade += 1
    
for i in altura:       
    if sexo == 'F':
        soma += i
        media_feminina = soma / quantidade

    if sexo == 'M':
        soma += i
        media_masculina = soma / quantidade

print(f'A maior altura é {maior} do sexo {sexo_maior} e a menor altura é {menor} do sexo {sexo_menor}')     
print()
print(f'A média de F: {media_feminina} e a média de M: {media_masculina}')
print()
print(f'O número total de indivíduos femininos é: {quantidade} e o total masculino é {quantidade}')
 