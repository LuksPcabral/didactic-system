g = [[None]*3 for i in range(3)] 

#pedindo os elementos da matriz
for i in range(3):
    for j in range(3):
        g[i][j] = int(input(f"Matriz {[i]}{[j]}: "))
        
#imprimir matriz 
print("\nMatriz:")
for i in range(3):
    print (g[i])

#alterar os elementos da linha e coluna 2
for i in range (3):
    g[2][i], g[i][2] = g[i][2], g[2][i]

print("\nMatriz com elementos trocados:")
 
#imprimir matriz com elementos trocados  
for i in range (3):
    print (g[i])