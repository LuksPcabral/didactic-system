import random 
n = int(input("Quantas vezes o dado foi lançado?"))

while (n != 0):
    lista = [0]*6
    
    for i in range(n):
        lado = random.randint(1, 6)
        lista[lado-1] += 1
    
    for i in range(len(lista)):
        lista[i] = lista[i]/n
    
    print ("O percentual de surgimento de cada face do dado e'" ,lista)  
    break 

while (n == 0):
    print ("Programa encerrado.")