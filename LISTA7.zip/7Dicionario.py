n = 0
while n != -1:
    inteiro = []
    dicionario = {}
    normal = str(input("Digite uma frase: "))
    caps = normal.upper()
    for c in range(len(caps)):
        cont = 0
        for i in caps:
            if caps[c] == i:
                cont += 1
        inteiro.append(cont)
    print(inteiro)
    for c in range(len(caps)):
        for i in normal:
            dicionario[normal[c]] = inteiro[c]
    print(dicionario)
    n = int(input("Deseja continuar? Se não, digite -1. Se sim, digite qualquer outro valor: "))