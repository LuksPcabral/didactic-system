alfabeto =['abcdefghijklmnopqrstuvwxyz]
mensagem = input("Digite a mensagem codificada (apenas ate o numero 26): ").split()
lista = []
   
for i in mensagem:
  i = int(i)
  lista.append(alfabeto[i])

a = ''
for i in lista:
    a += i

print(a)
