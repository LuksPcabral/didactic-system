lista = []
distancia = []
n = int(input("Qual a quantidade de pontos?"))

for i in range (1, n):
    x = int(input("Qual a coordenada x?"))
    y = int(input("Qual a coordenada y?"))
    ponto = x,y
    lista.append (ponto)