vetores1 = []
vetores2 = []
vetores3 = []

for i in range (5):
    vetores1.append(int(input("Vetor 1: ")))
    
for i in range (5):
    vetores2.append(int(input("Vetor 2: ")))
    
for i in range (5):
    vetores3.append(vetores1[i])
    vetores3.append(vetores2[i])
   
print (f'Vetor 3: {vetores3}')